const connection = require('../config/database');

class PokemonController {

    async listar(req, res) {
        try {
            const {
                tipo,
                nome,
                pagina = 1,
                limite = 10
            } = req.query;
            const offset = (pagina - 1) * limite;

            let query = "SELECT * FROM pokemons WHERE 1=1";
            let valores = [];
            if (tipo) {
                query += " AND tipo = ?";
                valores.push(tipo);
            }

            if (nome) {
                query += " AND nome LIKE ?";
                valores.push(`%${nome}%`);
            }

            query += " LIMIT ? OFFSET ?";
            valores.push(Number(limite), Number(offset));
            const [rows] = await connection.query(query, valores);
            res.json({
                pagina: Number(pagina),
                limite: Number(limite),
                resultados: rows
            });
        } catch (err) {
            res.status(500).json({
                erro: err.message
            });
        }
    }

    async criar(req, res) {
        try {
            const {
                id_box,
                nome,
                tipo,
                level_pokemon,
                hp,
                atk,
                def,
                sp_atk,
                sp_def,
                speed
            } = req.body;

            const [quantidade] = await connection.query(
                "SELECT COUNT(*) AS total FROM pokemons WHERE id_box = ?",
                [id_box]
            );
            if (quantidade[0].total >= 6) {
                return res.status(400).json({
                    erro: "Essa BOX já possui 6 Pokémons"
                });
            }

            const poder_total =
                hp + atk + def + sp_atk + sp_def + speed;

            const [result] = await connection.query(
                `INSERT INTO pokemons
                (
                    id_box,
                    nome,
                    tipo,
                    level_pokemon,
                    hp,
                    atk,
                    def,
                    sp_atk,
                    sp_def,
                    speed,
                    poder_total
                )
                VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
                [
                    id_box,
                    nome,
                    tipo,
                    level_pokemon,
                    hp,
                    atk,
                    def,
                    sp_atk,
                    sp_def,
                    speed,
                    poder_total
                ]
            );
            res.status(201).json({
                id: result.insertId,
                poder_total,
                ...req.body
            });
        } catch (err) {
            res.status(500).json({
                erro: err.message
            });
        }
    }

    async atualizar(req, res) {
        try {
            const { id } = req.params;
            const {
                nome,
                level_pokemon
            } = req.body;
            await connection.query(
                "UPDATE pokemons SET nome=?, level_pokemon=? WHERE id=?",
                [nome, level_pokemon, id]
            );
            res.json({
                mensagem: "Pokémon atualizado"
            });
        } catch (err) {
            res.status(500).json({
                erro: err.message
            });
        }
    }

    async deletar(req, res) {
        try {
            await connection.query(
                "DELETE FROM pokemons WHERE id=?",
                [req.params.id]
            );
            res.status(204).send();
        } catch (err) {
            res.status(500).json({
                erro: err.message
            });
        }
    }

    async buscarPokemonAPI(req, res) {
        try {
            const { nome } = req.params;
            const response = await fetch(
                `https://pokeapi.co/api/v2/pokemon/${nome}`
            );
            if (!response.ok) {
                return res.status(404).json({
                    erro: "Pokémon não encontrado"
                });
            }

            const data = await response.json();
            res.json(data);
        } catch (err) {
            res.status(500).json({
                erro: err.message
            });
        }
    }
}
module.exports = new PokemonController();